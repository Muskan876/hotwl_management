fetch('http://localhost:3000/api/rooms')
    .then(response => response.json())
    .then(rooms => {
        const roomsContainer = document.getElementById('rooms-container');

        rooms.forEach(room => {
            const roomCard = document.createElement('div');
            roomCard.classList.add('card');
            roomCard.innerHTML = `
                <img src="${room.image_url}" alt="${room.name}">
                <h3>${room.name}</h3>
                <p>${room.description}</p>
                <p>Price: $${room.price}</p>
                <a href="booking.html?room=${room.id}" class="book-now-btn">Book Now</a>
            `;
            roomsContainer.appendChild(roomCard);
        });
    })
    .catch(error => console.error('Error fetching rooms:', error));
