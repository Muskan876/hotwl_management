// Import required modules

const express = require('express');

const MySQL = require('mysql');

const bodyParser = require('body-parser');

const cors = require('cors');



// Create the Express app

const app = express();



// Enable Cross-Origin Request (CORS)

app.use(cors());



// Middleware to parse incoming JSON data

app.use(bodyParser.json());



// Create MySQL connection

const db = MySQL.createConnection({

    host: 'localhost',

    user: 'root', // Replace with your MySQL username

    password: '#Aditya123', // Replace with your MySQL password

    database: 'hotel_management' // Replace with your actual database name

});



// Connect to MySQL

db.connect((err) => {

    if (err) {

        console.error('Error connecting to the database:', err);

        return;

    }

    console.log('Connected to MySQL database');

});



// API Endpoint to get all rooms

app.get('/api/rooms', (req, res) => {

    db.query('SELECT * FROM rooms', (err, results) => {

        if (err) {

            console.error('Error fetching rooms:', err);  // Added console log for debugging

            res.status(500).json({ message: 'Database error' });

            return;

        }

        res.json(results);

    });

});



// API Endpoint to create a booking

app.post('/api/bookings', (req, res) => {

    const { name, email, room_id, check_in_date, check_out_date } = req.body;

    

    // Simple validation

    if (!name || !email || !room_id || !check_in_date || !check_out_date) {

        return res.status(400).json({ message: 'All fields are required' });

    }



    const query = 'INSERT INTO bookings (name, email, room_id, check_in_date, check_out_date) VALUES (?, ?, ?, ?, ?)';

    db.query(query, [name, email, room_id, check_in_date, check_out_date], (err, result) => {

        if (err) {

            console.error('Error creating booking:', err);  // Added console log for debugging

            res.status(500).json({ message: 'Error creating booking' });

            return;

        }

        res.json({ message: 'Booking created successfully', bookingId: result.insertId });

    });

});



// Start the server on port 3000

const port = 3000;

app.listen(port, () => {

    console.log(`Server is running on http://localhost:${port}`);

});